import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { UsersignupComponent } from './usersignup/usersignup.component';
import { MentorsignupComponent } from './mentorsignup/mentorsignup.component';
import { LoginComponent } from './login/login.component';
import { RouterModule } from'@angular/router';
import { AdminsignupComponent } from './adminsignup/adminsignup.component';
import { PaymentComponent } from './payment/payment.component';
import { ScheduleComponent } from './schedule/schedule.component';
import { UserprofileComponent } from './userprofile/userprofile.component';
import { MentorprofileComponent } from './mentorprofile/mentorprofile.component';

import { AdminprofileComponent } from './adminprofile/adminprofile.component';
import { HomeComponent } from './home/home.component';
import { UserproposedComponent } from './userproposed/userproposed.component';
import { UserdashComponent } from './userdash/userdash.component';
import { HomedashComponent } from './homedash/homedash.component';

import { MentorpaymentComponent } from './mentorpayment/mentorpayment.component';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { MentorsearchComponent } from './mentorsearch/mentorsearch.component';

import { MentorprogressComponent } from './mentorprogress/mentorprogress.component';
import { MentornotificationComponent } from './mentornotification/mentornotification.component';
import { AdminpaymentComponent } from './adminpayment/adminpayment.component';



@NgModule({
  declarations: [
    AppComponent,
    UsersignupComponent,
    MentorsignupComponent,
    LoginComponent,
    AdminsignupComponent,
    PaymentComponent,
    ScheduleComponent,
    UserprofileComponent,
    MentorprofileComponent,
   AdminprofileComponent,
    HomeComponent,
    UserproposedComponent,
    UserdashComponent,
    HomedashComponent,
 
    MentorpaymentComponent,
 
    MentorsearchComponent,
 

 
    MentorprogressComponent,
 
    MentornotificationComponent,
 
    AdminpaymentComponent,
 
  
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule, ReactiveFormsModule,
    
    

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
