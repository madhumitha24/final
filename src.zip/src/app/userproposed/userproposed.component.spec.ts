import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserproposedComponent } from './userproposed.component';

describe('UserproposedComponent', () => {
  let component: UserproposedComponent;
  let fixture: ComponentFixture<UserproposedComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserproposedComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserproposedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
