import { Component, OnInit } from '@angular/core';
import { Training } from '../model/Training';
import { TrainingsService } from '../service/trainings.service';
import { Router } from '@angular/router';
import { ApiService } from '../service/api.service';
import { User } from '../model/user.model';


@Component({
  selector: 'app-mentorprogress',
  templateUrl: './mentorprogress.component.html',
  styleUrls: ['./mentorprogress.component.css']
})
export class MentorprogressComponent implements OnInit {
  user:User;
  training:Training;

  constructor( private router: Router,private apiService: ApiService,private trainingsService:TrainingsService ) { }

  ngOnInit() {
    let userId = window.localStorage.getItem("user_id");
    if (!userId) {
      alert("Invalid action.")
      this.router.navigate(['login']);
      return;
    }
    this.apiService.getUserById(+userId)
    .subscribe( data => {
      this.user=data.result;
     
      console.log(data.result.first_name);
    });
    this.trainingsService.getCompletedMentor(+userId)
    .subscribe( data => {
    this.training=data;
      console.log(data);
    });
  }

}
