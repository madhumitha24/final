import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MentorprogressComponent } from './mentorprogress.component';

describe('MentorprogressComponent', () => {
  let component: MentorprogressComponent;
  let fixture: ComponentFixture<MentorprogressComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MentorprogressComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MentorprogressComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
