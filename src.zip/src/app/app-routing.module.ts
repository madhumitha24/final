import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { UsersignupComponent } from './usersignup/usersignup.component';
import { HomeComponent } from './home/home.component';
import { HomedashComponent } from './homedash/homedash.component';
import { MentorsignupComponent } from './mentorsignup/mentorsignup.component';
import { AdminsignupComponent } from './adminsignup/adminsignup.component';
import { UserprofileComponent } from './userprofile/userprofile.component';
import { MentorprofileComponent } from './mentorprofile/mentorprofile.component';
import { AdminprofileComponent } from './adminprofile/adminprofile.component';
import { MentorsearchComponent } from './mentorsearch/mentorsearch.component';
import { MentorpaymentComponent } from './mentorpayment/mentorpayment.component';
import { MentorprogressComponent } from './mentorprogress/mentorprogress.component';
import { MentornotificationComponent } from './mentornotification/mentornotification.component';
import { UserdashComponent } from './userdash/userdash.component';
import { UserproposedComponent } from './userproposed/userproposed.component';
import { AdminpaymentComponent } from './adminpayment/adminpayment.component';

const routes: Routes = [{path:'',component:HomedashComponent},
{path:'login',component:LoginComponent},
{path:'usersignup',component:UsersignupComponent},
{path:'mentorsignup',component:MentorsignupComponent},
{path:'adminsignup',component:AdminsignupComponent},
{path:'homedash',component:HomedashComponent},
{path:'userprofile',component:UserprofileComponent},
{path:'mentorprofile',component:MentorprofileComponent},
{path:'adminprofile',component:AdminprofileComponent},
{path:'home',component:HomeComponent},
{path:'mentorpayment',component:MentorpaymentComponent},
{path:'mentorprogress',component:MentorprogressComponent},
{path:'mentornotification',component:MentornotificationComponent},
{path:'userdash',component:UserdashComponent},
{path:'mentorsearch',component:MentorsearchComponent},
{path:'userproposed',component:UserproposedComponent},
{path:'adminpayment',component:AdminpaymentComponent}


];
 
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
